package com.devdiv.test.ui_test_gallery;

/*
 * 1��ע��attrs.xml�ļ������ݣ���JAVA�ļ������ú����õķ�ʽ��
 *      ********************************
 * 		// ʵ�ò����ļ��е�Gallery����
 *  	TypedArray a = obtainStyledAttributes(R.styleable.Gallery);
 *		// ȡ��gallery���Զ�index id
 *   	myGalleryItemBackground = a.getResourceId(R.styleable.Gallery_android_galleryItemBackground, 0);
 *   	// �ö����styleable�����ܷ���ʵ��
 *   	a.recycle();
 *      **********************************
 *      //���ñ�����
 *		myImageView.setBackgroundResource(myGalleryItemBackground);
 * 
 * 2��ע��ImageView��һЩ���÷�����ϸ��
 *    myImageView.setScaleType(ImageView.ScaleType.FIT_XY); 
 *    myImageView.setLayoutParams(new Gallery.LayoutParams(100, 220));	
 * 
 * 3��Gallery��ʹ�÷�����ListView����
 */

import android.app.Activity;
import android.content.Context;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Gallery;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class UI_Test_GalleryActivity extends Activity {
	
	private Gallery myGallery;
	private TextView myTextView;
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        myGallery = (Gallery) findViewById(R.id.mygallery);
        myGallery.setAdapter(new MyImageAdapter(this));
        
        myGallery.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View v, int position,
					long id) {
				// TODO Auto-generated method stub
				Toast.makeText(UI_Test_GalleryActivity.this, "Click Image" + position, Toast.LENGTH_SHORT).show();
			}
		});
        
    }
    
    public class MyImageAdapter extends BaseAdapter {
    	
    	private int[] imageId = {R.drawable.i1, R.drawable.i2, R.drawable.i3, R.drawable.i4,
    			                 R.drawable.i1, R.drawable.i2, R.drawable.i3, R.drawable.i4,
    			                 R.drawable.i1, R.drawable.i2, R.drawable.i3, R.drawable.i4,};
    	
    	private int myGalleryItemBackground;
    	private Context myContext;
    	
    	public MyImageAdapter(Context context) {
    		
    		myContext = context;
    		
    		/*
    		 * TypedArray:
    		 * 
    		 * Container for an array of values that were retrieved with obtainStyledAttributes(AttributeSet, int[], int, int) or obtainAttributes(AttributeSet, int[]). 
    		 * Be sure to call recycle() when done with them. 
    		 * The indices used to retrieve values from this structure correspond to the positions of the attributes given to obtainStyledAttributes
    		 */
    		
    		/*
    		 * �ⲿ�ֿ��Ĳ����ر����ף����ʹ��Gallery�ı���ʽ��
    		 */
    		
    		// ʵ�ò����ļ��е�Gallery����
    		TypedArray a = obtainStyledAttributes(R.styleable.Gallery);
    		// ȡ��gallery���Զ�index id
    		myGalleryItemBackground = a.getResourceId(R.styleable.Gallery_android_galleryItemBackground, 0);
    		// �ö����styleable�����ܷ���ʵ��
    		a.recycle();	
    	}
    	

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return imageId.length;
		}

		@Override
		public Object getItem(int position) {
			// TODO Auto-generated method stub
			return imageId[position];
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return position;
		}

		@Override
		public View getView(int position, View converView, ViewGroup parent) {
			// TODO Auto-generated method stub
			ImageView myImageView = new ImageView(myContext);
			//����ImageView�ڵ�ͼƬ��Դ
			myImageView.setImageResource(imageId[position]);
			//���ñ�����
			myImageView.setBackgroundResource(myGalleryItemBackground);
			//����ͼƬ������ģʽ
			myImageView.setScaleType(ImageView.ScaleType.FIT_XY);
			//����ImageView�Ĳ��֣�300*420
			myImageView.setLayoutParams(new Gallery.LayoutParams(300, 420));
//			myImageView.setLayoutParams(new Gallery.LayoutParams(100, 220));
			
			return myImageView;
		}
    }
}