package com.wenqier.send;

import java.io.PrintStream;
import java.net.Socket;

import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 * ���Ϳͻ��˵���Ϣ
 * @author wenqier
 *
 */
public class SendMessage extends Thread {
	private String ip;
	private int i;
	Socket s = null;
	JLabel label = null;
	JTextField text;
	JTextArea text1;

	public SendMessage(String ip, int i, JTextArea text1) {
		this.ip = ip;
		this.i = i;
		this.text1 = text1;

	}

	public void run() {

		while (true) {
			try {
				s = new Socket(ip, i);
				text1.setText("���ӳɹ�" + "\n");
				break;
			} catch (Exception e) {
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e1) {
					System.out.println("�����ˡ�������");
				}
			}
		}

	}

	public void send(String message) {
		try {

			PrintStream p = new PrintStream(s.getOutputStream());

			p.println(message);

		} catch (Exception e1) {
			System.out.println("�쳣" + e1.getMessage());
		}
	}

}
