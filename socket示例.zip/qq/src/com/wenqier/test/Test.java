package com.wenqier.test;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import com.wenqier.get.GetMessage;
import com.wenqier.send.SendMessage;

/**
 * �û�����
 * @author wenqier
 *
 */
class WindowTextArea extends JFrame implements ActionListener {

	String s;
	JTextArea text1;
	JTextArea text2;
	JButton button1, button2, button3;
	SendMessage t2;
	GetMessage t1;
	JLabel lable1, lable2;
	JTextField text;
	JPanel jPanel;

	WindowTextArea() {

		jPanel = new JPanel();
		
		lable1 = new JLabel("�Է�ip");
		text = new JTextField(20);

		text1 = new JTextArea(3, 38);
		text2 = new JTextArea(6, 38);
		text2.setEditable(false);
		
		button1 = new JButton("����");
		button2 = new JButton("�ر�");
		button3 = new JButton("ȷ��ip");

		setBounds(100, 100, 450, 300);
		setVisible(true);
		
		Container con = getContentPane();
		con.setLayout(new FlowLayout());
		con.add(lable1);
		con.add(text);
		con.add(button3);

		BorderLayout b = new BorderLayout();
		jPanel.setLayout(b);
		
		jPanel.add(new JScrollPane(text1), b.SOUTH);
		jPanel.add(new JScrollPane(text2), b.NORTH);
		
		con.add(jPanel);

		con.add(button1);
		con.add(button2);

		button1.addActionListener(this);
		button2.addActionListener(this);
		button3.addActionListener(this);
		con.validate();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}

	public void runthread(String ip) {
		t1 = new GetMessage(5050, text2);
		t1.start();
		t2 = new SendMessage(ip, 5050, text2);
		t2.start();
	}

	public void actionPerformed(ActionEvent e) {
		// �¼���������
		if (e.getSource() == button2) {
			System.exit(0);
		}
		if (e.getSource() == button1) {

			text2.append("��˵��" + text1.getText() + "\n");

			t2.send(text1.getText());

			text1.setText("");
		}
		if (e.getSource() == button3) {
			s = text.getText();

			runthread(s);

		}
	}
}

/**
 * ����
 * 
 * @author wenqier
 * 
 */
public class Test {

	public static void main(String[] args) {

		new WindowTextArea();

	}
}