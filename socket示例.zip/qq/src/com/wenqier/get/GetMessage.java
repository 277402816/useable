package com.wenqier.get;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;

import javax.swing.JLabel;
import javax.swing.JTextArea;

/**
 * ���տͻ��˵���Ϣ
 * @author wenqier
 *
 */
public class GetMessage extends Thread {
	private int i;
	String v;

	JLabel label = null;
	private JTextArea text;

	public GetMessage(int i, JTextArea text) {
		this.i = i;
		this.text = text;
	}

	public void run() {
		try {
			ServerSocket so = new ServerSocket(i);
			Socket s = so.accept();
			while (true) {
				InputStreamReader i = new InputStreamReader(s.getInputStream());
				BufferedReader b = new BufferedReader(i);
				v = b.readLine();
				text.append("�Է�˵��" + v + "\n");
			}
		} catch (IOException e) {
			text.append("�Է������ˡ�����");
		}
	}
}