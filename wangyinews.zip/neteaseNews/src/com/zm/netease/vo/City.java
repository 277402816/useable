package com.zm.netease.vo;

public class City {
	private Integer id;
	private String cityName;
	private String cityProvince;
	private String cityPinyin;
	private Integer citySelectCount;
	public City() {
	}
	public City(Integer id, String cityName, String cityProvince,
			String cityPinyin, Integer citySelectCount) {
		this.id = id;
		this.cityName = cityName;
		this.cityProvince = cityProvince;
		this.cityPinyin = cityPinyin;
		this.citySelectCount = citySelectCount;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	public String getCityProvince() {
		return cityProvince;
	}
	public void setCityProvince(String cityProvince) {
		this.cityProvince = cityProvince;
	}
	public String getCityPinyin() {
		return cityPinyin;
	}
	public void setCityPinyin(String cityPinyin) {
		this.cityPinyin = cityPinyin;
	}
	public Integer getCitySelectCount() {
		return citySelectCount;
	}
	public void setCitySelectCount(Integer citySelectCount) {
		this.citySelectCount = citySelectCount;
	}
}
