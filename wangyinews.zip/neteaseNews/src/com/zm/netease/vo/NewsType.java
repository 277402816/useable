package com.zm.netease.vo;

public class NewsType {
	private Integer newsTypeId;
	private String newsTypeName;
	private String newsTypeFlag;
	public Integer getNewsTypeId() {
		return newsTypeId;
	}
	public void setNewsTypeId(Integer newsTypeId) {
		this.newsTypeId = newsTypeId;
	}
	public String getNewsTypeName() {
		return newsTypeName;
	}
	public void setNewsTypeName(String newsTypeName) {
		this.newsTypeName = newsTypeName;
	}
	public String getNewsTypeFlag() {
		return newsTypeFlag;
	}
	public void setNewsTypeFlag(String newsTypeFlag) {
		this.newsTypeFlag = newsTypeFlag;
	}
}
