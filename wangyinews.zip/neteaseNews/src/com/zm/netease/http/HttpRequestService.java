package com.zm.netease.http;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import android.content.Context;

public class HttpRequestService {
	private HttpClient httpClient;
	public String loadDataForNormal(String url){
		String content = "";
		httpClient = new DefaultHttpClient();
		HttpGet request = new HttpGet(url);
		try {
			HttpResponse response = httpClient.execute(request);
			if(response.getStatusLine().getStatusCode()==200){
				content = EntityUtils.toString(response.getEntity(), "UTF-8");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return content;
	}
	public String requestByPost(String url, Map<String, String> params){
				String content = "";
				try {
					httpClient = new DefaultHttpClient();
					HttpPost request = new HttpPost(url);
					List<NameValuePair> args = new ArrayList<NameValuePair>();
					for(Map.Entry<String,String> entry:params.entrySet()){
						args.add(new BasicNameValuePair(entry.getKey(), entry.getValue()));
					}
					UrlEncodedFormEntity entity = new UrlEncodedFormEntity(args,"UTF-8");
					request.setEntity(entity);
					//浏览器去执行这次get请求，返回一个响应对象
					HttpResponse response = httpClient.execute(request);
					//获取响应码
					int code = response.getStatusLine().getStatusCode();
					if(code==200){
						//读取响应的内容
						content = EntityUtils.toString(response.getEntity(), "UTF-8");
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
				return content;
	}
	//获取图像资源
	public void putPhoto(String photoName,File file,Context context){
		FileOutputStream output=null;
		InputStream input=null;
		HttpClient client=new DefaultHttpClient();
		int len = 0;
		try{
			HttpResponse response=client.execute(new HttpGet(HttpRequestUrl.URL+photoName));
			byte[] buffer=new byte[1024];
			output=context.openFileOutput(photoName.split("/")[1],Context.MODE_WORLD_WRITEABLE);
			if(response.getStatusLine().getStatusCode()==200){
				input=response.getEntity().getContent();
				while((len=input.read(buffer))!=-1){
					output.write(buffer,0,len);
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			if(input!=null){
				try {
					input.close();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
			if(output!=null){
				try {
					output.close();
				} catch (IOException e1) {
					e1.printStackTrace();
				}	
			}
		}
	
}
	
}
