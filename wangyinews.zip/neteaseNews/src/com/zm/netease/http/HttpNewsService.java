package com.zm.netease.http;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import android.util.Log;

import com.zm.netease.vo.Comments;
import com.zm.netease.vo.News;
import com.zm.netease.vo.NewsFilmResource;

public class HttpNewsService extends HttpRequestService{
	private JSONObject json = null;
	private JSONArray arrayUrl = null;
	private Comments comment = null;
	public List<News> parseNews(String data){
		List<News> newsList = new ArrayList<News>();
		List<NewsFilmResource> photos = new ArrayList<NewsFilmResource>();
		News news;
		try {
			json = new JSONObject(data);
			JSONArray jsonArray = json.getJSONArray("news");
			if(jsonArray.length()>0){
				for(int i=0;i<jsonArray.length();i++){
					json = jsonArray.getJSONObject(i);
					news = new News();
					news.setCommentsCount(json.getInt("commentsCount"));
					news.setNewsAddress(json.getString("newsAddress"));
					news.setNewsContent(json.getString("newsContent"));
					news.setNewsData(json.getString("newsParserData"));
					news.setNewsId(json.getInt("newsId"));
					news.setNewsSource(json.getString("newsSource"));
					news.setNewsTitle(json.getString("newsTitle"));
					arrayUrl = new JSONArray(json.getString("photos"));
					if(arrayUrl.length()>0){
						for(int j=0;j<arrayUrl.length();j++){
							json = arrayUrl.getJSONObject(j);
							photos.add(new NewsFilmResource(json.getString("newsFilmResourceUrl")));
						}
						news.setPhotos(photos);
					}else{
						news.setPhotos(null);
					}
					newsList.add(news);
			    }
			}
		} catch (Exception e) {
			e.printStackTrace();
		}		
		return newsList;
	}
	public News loadNews(String data){
		News news = new News();
		List<NewsFilmResource> photos = new ArrayList<NewsFilmResource>();
		try {
			JSONObject jsonChild;
			JSONArray jsonArray = new JSONArray(data);
			for(int i=0;i<jsonArray.length();i++){
				json = jsonArray.getJSONObject(i);
				news.setCommentsCount(json.getInt("commentsCount"));
				news.setNewsAddress(json.getString("newsAddress"));
				news.setNewsContent(json.getString("newsContent"));
				news.setNewsData(json.getString("newsParserData"));
				news.setNewsId(json.getInt("newsId"));
				news.setNewsSource(json.getString("newsSource"));
				news.setNewsTitle(json.getString("newsTitle"));
				arrayUrl = new JSONArray(json.getString("photos"));
				if(arrayUrl.length()>0){
					for(int j=0;j<arrayUrl.length();j++){
						jsonChild = arrayUrl.getJSONObject(j);
						photos.add(new NewsFilmResource(jsonChild.getString("newsFilmResourceUrl")));
					}
				}
				news.setPhotos(photos);
				news.setComments(comments(new JSONArray(json.getString("comments"))));
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.e("TAG", "报错了");
		}
		return news;
	}
	private List<Comments> comments(JSONArray arrayUrl){
		List<Comments> comments = new ArrayList<Comments>();
		JSONObject json;
		try {
			if(arrayUrl.length()>0){
				for(int j=0;j<arrayUrl.length();j++){
					json = arrayUrl.getJSONObject(j);
					comments.add(getComments(json));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return comments;
	}
	public List<Comments> parseComments(String data,List<Comments> list){
		
		try {
			json = new JSONObject(data);
			arrayUrl = json.getJSONArray("comments");
			if(arrayUrl.length()>0){
				for(int j=0;j<arrayUrl.length();j++){
					json = arrayUrl.getJSONObject(j);
					list.add(getComments(json));
				}
			}else{
				list = null;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	private Comments getComments(JSONObject json)throws Exception{
		comment = new Comments();
		comment.setCommentsContent(json.getString("commentsContent"));
		comment.setCommentsData(json.getString("commentsParserData"));
		comment.setCommentsUserId(json.getInt("commentsUserId"));
		comment.setUserAddress(json.getString("userAddress"));
		comment.setUserName(json.getString("userName"));
		comment.setUserPhoto(json.getString("userPhoto"));
		comment.setCommentsId(json.getInt("commentsId"));
		return comment;
	}
}
