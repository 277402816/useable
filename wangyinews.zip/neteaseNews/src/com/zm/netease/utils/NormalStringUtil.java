package com.zm.netease.utils;

public class NormalStringUtil {
	private NormalStringUtil(){};
	public static final String REGISTER_OK = "注册成功";
}
