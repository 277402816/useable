package com.zm.netease;

import java.util.HashMap;
import java.util.Map;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;

import com.zm.netease.http.HttpRequestUrl;
import com.zm.netease.http.HttpUserService;
import com.zm.netease.utils.ActivityUtil;
import com.zm.netease.utils.NormalStringUtil;
import com.zm.netease.utils.StringUtils;

public class RegisterActivity extends Activity {
	private EditText et_number,et_password,et_countersign_password;
	private HttpUserService userService;
	private Map<String,String> params;
	private CheckBox cb_agree;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);
        initView();
    }
    private void initView() {
		et_countersign_password = (EditText) findViewById(R.id.et_countersign_password);
		et_number = (EditText) findViewById(R.id.et_number);
		et_password = (EditText) findViewById(R.id.et_password);
		cb_agree = (CheckBox) findViewById(R.id.cb_agree);
		userService = new HttpUserService();
			
	}
	public void register(View view){
		if(!cb_agree.isChecked()){
			ActivityUtil.toast(this, "请选择我同意");
			return;
		}
		String number = et_number.getText().toString();
		String password = et_password.getText().toString();
		String countersignPassword = et_countersign_password.getText().toString();
		String address = "湖南省长沙市";
		if(StringUtils.isBlank(number)){
			ActivityUtil.toast(this, "请输入您的手机号码");
			return;
		}
		if(StringUtils.isBlank(password)){
			ActivityUtil.toast(this, "请输入密码");
			return;
		}
		if(password.length()<6 || password.length()>11){
			ActivityUtil.toast(this, "密码输入不合法");
			et_password.setText(null);
			et_countersign_password.setText(null);
			return;
		}
		if(StringUtils.isBlank(countersignPassword)){
			ActivityUtil.toast(this, "请输入确认密码");
			return;
		}
		if(!countersignPassword.equals(password)){
			ActivityUtil.toast(this, "以上一次输入的密码不一致,请重新输入");
			return;
		}
		params = new HashMap<String, String>();
		params.put("user.userNumber", number+"@163.com");
		params.put("user.userName", number);
		params.put("user.userPassword", password);
		params.put("user.userAddress", address);
		String data = userService.requestByPost(HttpRequestUrl.url(HttpRequestUrl.USER_REGISTER), params);
		ActivityUtil.toast(this, data);
		if(data.endsWith(NormalStringUtil.REGISTER_OK)){
			this.setResult(RESULT_OK);
			finish();
		}
		
    }
    public void returnLogin(View view){
    	this.setResult(RESULT_OK);
		finish();
    }
}