package com.zm.netease;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.ViewSwitcher;

import com.zm.netease.adapter.MyAdapter;
import com.zm.netease.http.HttpNewsService;
import com.zm.netease.http.HttpRequestUrl;
import com.zm.netease.utils.ActivityUtil;
import com.zm.netease.view.MyListView;
import com.zm.netease.view.MyListView.OnRefreshListener;
import com.zm.netease.vo.News;

public class TabNewsScienceActivity extends Activity {
	private MyListView listView;
	private ViewSwitcher viewSwitcher;
	private Map<String,String> params;
	private HttpNewsService newsService;
	private String title;
	private MyAdapter adapter;
	private List<News> list;
	private Button button;
	private ActivityUtil activityUtil;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.layout_news_science);
		setTheme(android.R.style.Theme_Translucent_NoTitleBar);

		initViews();

		requestRSSFeed();

	}

	private void initViews() {
		viewSwitcher = (ViewSwitcher) findViewById(R.id.viewswitcher_news_science);
		listView = new MyListView(this);
		listView.setCacheColorHint(Color.argb(0, 0, 0, 0));
		button = new Button(this);
		button.setText("查看更多的新闻");
		button.setHint(21+"");
		activityUtil = new ActivityUtil();
		button.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				int startIndex = Integer.parseInt(button.getHint().toString());
				int endIndex = startIndex+ActivityUtil.COUNT;
				list = activityUtil.nextPage(list,startIndex,endIndex,HttpRequestUrl.URL_NEWS_SCIENCE);
				if(list==null){
					ActivityUtil.toast(TabNewsScienceActivity.this, "没有更多的新闻加载了");
				}else{
					adapter.notifyDataSetChanged();
					button.setHint(endIndex+"");
				}
			}
		});
		listView.addFooterView(button);
		listView.setonRefreshListener(new OnRefreshListener() {
			
			@Override
			public void onRefresh() {
				new AsyncTask<Map<String,String>, Integer, List<News>>(){

					@Override
					protected List<News> doInBackground(Map<String, String>... params) {
						try {
							Thread.sleep(1000);
						} catch (Exception e) {
							e.printStackTrace();
						}
						data();
						return list;
					}
					@Override
					protected void onPostExecute(List<News> result) {
						button.setHint(21+"");
						listView.setAdapter(new MyAdapter(list, TabNewsScienceActivity.this));
						listView.onRefreshComplete();
					}
					
				}.execute(null);
			}
		});
		viewSwitcher.addView(listView);
		viewSwitcher.addView(getLayoutInflater().inflate(R.layout.layout_progress_page, null));
		viewSwitcher.showNext();
		listView.setOnItemClickListener(listener);
		newsService = new HttpNewsService();
		params = new HashMap<String, String>();
		title = this.getIntent().getStringExtra("title");

	}

	private void requestRSSFeed() {
		Thread t = new Thread() {
			@Override
			public void run() {
				super.run();
				try {
					data();
					if (list.size() == 0) {
						handler.sendEmptyMessage(-1);
					} else {
						handler.sendEmptyMessage(1);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		};
		t.start();
	}
	private void data(){
		params.clear();
		params.put("news.newsTitle", title);
		String data = newsService.requestByPost(HttpRequestUrl.url(HttpRequestUrl.NEWS_SELECT),params);
		list = newsService.parseNews(data);
		
	}
	private Handler handler = new Handler() {
		public void handleMessage(android.os.Message msg) {
			if (msg.what == 1) {
				adapter = new MyAdapter(list,TabNewsScienceActivity.this);
				listView.setOnItemClickListener(listener);
				listView.setAdapter(adapter);
				viewSwitcher.showPrevious();
			}
		};
	};

	private OnItemClickListener listener = new OnItemClickListener() {

		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
			Intent intent = new Intent(TabNewsScienceActivity.this, NewsContentActivity.class);
			intent.putExtra("content_url", list.get(position-1).getNewsId()+"");
			intent.putExtra("count", list.get(position-1).getCommentsCount()+"");
			TabNewsScienceActivity.this.startActivityForResult(intent, position);
		}
	};

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		System.out.println("返回");
		if (resultCode == RESULT_OK) {
			// 确认中
			View v = (View) listView.getItemAtPosition(requestCode);
			TextView tv = (TextView) v.findViewById(R.id.tv_title_news_top_item);
			tv.setText("hello");
			adapter.notifyDataSetChanged();
		}
	}
}