package com.zm.netease;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.ViewSwitcher;

import com.zm.netease.adapter.MyAdapter;
import com.zm.netease.http.HttpNewsService;
import com.zm.netease.http.HttpRequestUrl;
import com.zm.netease.utils.ActivityUtil;
import com.zm.netease.view.MyListView;
import com.zm.netease.view.MyListView.OnRefreshListener;
import com.zm.netease.vo.News;
//话题
public class TabTopicActivity extends Activity {

	private MyListView listView;

	private List<News> list;

	private MyAdapter adapter;

	private ViewSwitcher viewSwitcher;
	private Map<String,String> params;
	private HttpNewsService newsService;

	private Button button;

	private ActivityUtil activityUtil;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.layout_topic);
		setTheme(android.R.style.Theme_Translucent_NoTitleBar);

		initViews();
		requestRSSFeed();

	}

	private void initViews() {
		viewSwitcher = (ViewSwitcher) findViewById(R.id.viewswitcher_tab_topic);
		listView = new MyListView(this);
		listView.setCacheColorHint(Color.argb(0, 0, 0, 0));
		button = new Button(this);
		button.setText("查看更多的话题");
		button.setHint(21+"");
		activityUtil = new ActivityUtil();
		button.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				int startIndex = Integer.parseInt(button.getHint().toString());
				int endIndex = startIndex+ActivityUtil.COUNT;
				list = activityUtil.nextPage(list,startIndex,endIndex,HttpRequestUrl.URL_TOPIC);
				if(list==null){
					ActivityUtil.toast(TabTopicActivity.this, "已全部加载了");
				}else{
					adapter.notifyDataSetChanged();
					button.setHint(endIndex+"");
				}
			}
		});
		listView.addFooterView(button);
		listView.setonRefreshListener(new OnRefreshListener() {
			
			@Override
			public void onRefresh() {
				new AsyncTask<Map<String,String>, Integer, List<News>>(){

					@Override
					protected List<News> doInBackground(Map<String, String>... params) {
						try {
							Thread.sleep(1000);
						} catch (Exception e) {
							e.printStackTrace();
						}
						data();
						return list;
					}
					@Override
					protected void onPostExecute(List<News> result) {
						button.setHint(21+"");
						listView.setAdapter(new MyAdapter(list, TabTopicActivity.this));
						listView.onRefreshComplete();
					}
					
				}.execute(null);
			}
		});
		viewSwitcher.addView(listView);
		viewSwitcher.addView(getLayoutInflater().inflate(R.layout.layout_progress_page, null));
		viewSwitcher.showNext();
		listView.setOnItemClickListener(listener);
		newsService = new HttpNewsService();
		params = new HashMap<String, String>();

	}

	private void requestRSSFeed() {
		Thread t = new Thread() {
			@Override
			public void run() {
				super.run();
				try {
					data();
					if (list.size() == 0) {
						handler.sendEmptyMessage(-1);
					} else {
						handler.sendEmptyMessage(1);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		};
		t.start();
	}
	private void data(){
		params.clear();
		params.put("news.newsTitle", HttpRequestUrl.URL_TOPIC);
		String data = newsService.requestByPost(HttpRequestUrl.url(HttpRequestUrl.NEWS_SELECT),params);
		list = newsService.parseNews(data);
	}
	Handler handler = new Handler() {
		public void handleMessage(android.os.Message msg) {
			if (msg.what == 1) {
				adapter = new MyAdapter(list,TabTopicActivity.this);
				listView.setOnItemClickListener(listener);
				listView.setAdapter(adapter);
				viewSwitcher.showPrevious();
			}
		};
	};

	private OnItemClickListener listener = new OnItemClickListener() {

		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
			if(position==1){
				return;
			}
			Intent intent = new Intent(TabTopicActivity.this, NewsContentActivity.class);
			intent.putExtra("content_url", list.get(position-1).getNewsId()+"");
			intent.putExtra("count", list.get(position-1).getCommentsCount()+"");
			TabTopicActivity.this.startActivityForResult(intent, position);
		}
	};

}
