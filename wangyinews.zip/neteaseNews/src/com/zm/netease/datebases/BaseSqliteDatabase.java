package com.zm.netease.datebases;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class BaseSqliteDatabase extends SQLiteOpenHelper {
	public static final String CITY_LIST = "CITY_LIST";
	public BaseSqliteDatabase(Context context,int vision) {
		super(context, "netease.db", null, vision);
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		db.execSQL("CREATE TABLE CITY_LIST(_id INTEGER PRIMARY KEY AUTOINCREMENT," +
				"CITY_NAME NTEXT,CITY_PROVINCE NTEXT,CITY_PINYIN NTEXT," +
				"CITY_SELECT_COUNT INTEGER)");
		db.execSQL("INSERT INTO CITY_LIST VALUES('长沙','湖南','changsha',0)");
		db.execSQL("INSERT INTO CITY_LIST VALUES('常德','湖南','changde',0)");

	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		db.execSQL("DROP CITY_LIST");
		this.onCreate(db);
	}

}
