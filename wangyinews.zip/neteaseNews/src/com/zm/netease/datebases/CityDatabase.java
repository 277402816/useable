package com.zm.netease.datebases;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.zm.netease.vo.City;

public class CityDatabase {

	private BaseSqliteDatabase database;
	private SQLiteDatabase db;
	public CityDatabase(Context context){
		database = new BaseSqliteDatabase(context, 1);
	}
	public List<City> queryAll(){
		List<City> citys = new ArrayList<City>();
		City city = null;
		db = database.getReadableDatabase();
		Cursor cursor = db.rawQuery("SELECT * FROM "+BaseSqliteDatabase.CITY_LIST, null);
		while(cursor.moveToNext()){
			city = new City();
			city.setCityName(cursor.getString(cursor.getColumnIndex("CITY_NAME")));
			city.setCityProvince(cursor.getString(cursor.getColumnIndex("CITY_PROVINCE")));
			citys.add(city);
		}
		cursor.close();
		return citys;
	}
}
