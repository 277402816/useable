package com.zm.netease.task;

public class NewsTask {

}
