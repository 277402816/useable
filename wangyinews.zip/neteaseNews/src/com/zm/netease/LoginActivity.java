package com.zm.netease;

import java.util.HashMap;
import java.util.Map;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.zm.netease.http.HttpRequestUrl;
import com.zm.netease.http.HttpUserService;
import com.zm.netease.utils.ActivityUtil;
import com.zm.netease.utils.StringUtils;
import com.zm.netease.vo.Users;

public class LoginActivity extends Activity {
	private EditText et_number,et_password;
	private Intent intent;
	private Map<String,String> parmes;
	private HttpUserService userService;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        initView();
    }
	private void initView() {
		et_number = (EditText) findViewById(R.id.et_number);
		et_password = (EditText) findViewById(R.id.et_password);
		userService = new HttpUserService();
	}
	//登录
	public void login(View view){
		String number = et_number.getText().toString();
		String password = et_password.getText().toString();
		if(StringUtils.isBlank(number)){
			ActivityUtil.toast(this,"请输入账号");
			return;
		}
		if(StringUtils.isBlank(password)){
			ActivityUtil.toast(this,"请输入账号");
			return;
		}
		if(!number.contains("@163.com")){
			number += "@163.com";
			et_number.setText(number);
		}
		parmes = new HashMap<String, String>();
		parmes.put("user.userNumber", number);
		parmes.put("user.userPassword", password);
		String data = userService.requestByPost(HttpRequestUrl.url(HttpRequestUrl.USER_LOGIN),parmes);
		Users.user = userService.parserUser(data);
		if(Users.user == null){
			ActivityUtil.toast(this, "您输入的密码不正确");
			return;
		}
		this.setResult(RESULT_OK);
		finish();
		
		
	}
	//跳转到注册页面
	public void register(View view){
		intent = new Intent(this,RegisterActivity.class);
		this.startActivityForResult(intent, 1);
	}
	
	//跳转到主页面
	public void returnIndex(View view){
		this.setResult(RESULT_OK);
		finish();
	}
    
}