package com.zm.netease;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

import com.zm.netease.adapter.NewsMoreAdapter;
import com.zm.netease.http.HttpRequestUrl;

public class TabNewsMoreActivity extends Activity {

	private ListView listView;
	private String array[];

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.layout_news_more);

		array = getResources().getStringArray(R.array.more);
		listView = (ListView) findViewById(R.id.listView_news_more);
		listView.setAdapter(new NewsMoreAdapter(array,this));
		
		listView.setOnItemClickListener(listener);
	}
	
	private OnItemClickListener listener = new OnItemClickListener() {

		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position,
				long id) {
			Intent intent = new Intent(TabNewsMoreActivity.this, NewsMoreContentActivity.class);
			Bundle bundle = new Bundle();
			switch (position) {
			case 0:
				bundle.putString("more_news_list_url", HttpRequestUrl.URL_NEWS_DOMESTIC);
				break;
			case 1:
				bundle.putString("more_news_list_url", HttpRequestUrl.URL_NEWS_MILITARY);
				break;
			case 2:
				bundle.putString("more_news_list_url", HttpRequestUrl.URL_NEWS_INTERNATIONAL);
				break;
			case 3:
				bundle.putString("more_news_list_url", HttpRequestUrl.URL_NEWS_COMMUNITY);
				break;
			case 4:
				bundle.putString("more_news_list_url", HttpRequestUrl.URL_NEWS_DEPTH);
				break;
			case 5:
				bundle.putString("more_news_list_url", HttpRequestUrl.URL_NEWS_TICKET);
				break;
			case 6:
				bundle.putString("more_news_list_url", HttpRequestUrl.URL_NEWS_FILM);
				break;
			case 7:
				bundle.putString("more_news_list_url", HttpRequestUrl.URL_NEWS_MUSIC);
				break;
			case 8:
				bundle.putString("more_news_list_url", HttpRequestUrl.URL_NEWS_IT);
				break;
			case 9:
				bundle.putString("more_news_list_url", HttpRequestUrl.URL_NEWS_CAR);
				break;
			case 10:
				bundle.putString("more_news_list_url", HttpRequestUrl.URL_NEWS_DIGITAL);
				break;
			}
			
			bundle.putString("text", array[position]);
			intent.putExtras(bundle);
			TabNewsMoreActivity.this.startActivity(intent);
			
		}
	};

}
