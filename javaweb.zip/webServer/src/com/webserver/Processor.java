package com.webserver;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.Socket;

public class Processor extends Thread {

	private Socket socket;
	private InputStream in;
	private PrintStream out;
	public final static String WEB_ROOT = "E:\\projects\\javaprojects\\htmls";//该目录下需要存在html文档
	public Processor(Socket socket) {
		this.socket = socket;
		
		try {
			in = socket.getInputStream();
			out = new PrintStream(socket.getOutputStream());
		} catch (IOException e) {
		
			e.printStackTrace();
		}
		
	}

	public void run() {
		String fileName = this.parse(in);
		this.sendFile(fileName);
	}

	public String parse(InputStream in) {

		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		String fileName = null;
		try {
			String httpMessage = br.readLine();
			String[]content = httpMessage.split(" ");//协议状态号，名称，版本号
			
			//如果客戶端輸入协议错误则返回错误页面
			if(content.length != 3) {
				this.sendErrorMessage(400, "Client query error！");
				return null;
			}
			//否则输出协议信息
			System.out.println("code:"+content[0]+",filename"+content[1]+
					"httpversion:"+content[2]);
			
			fileName = content[1];
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		return fileName;

	}

	//错误页面输出方法
	public void sendErrorMessage(int ErrorCode, String ErrorContent) {

		out.println("HTTP/1.0 "+ErrorCode+" "+ErrorContent);
		out.println("content-type: text/html");
		out.println();
		out.println("<html>");
		
		out.println("<title>Error Message");
		out.println("</title>");
		out.println("<body>");
		out.println("<h1>ErrorCode:"+ErrorCode+",Message:"+ErrorContent+"</h1>");		
		
		out.println("</body>");
		out.println("</html>");
		
		out.flush();
		out.close();
		try {
			in.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void sendFile(String fileName) {
		File file = new File(Processor.WEB_ROOT+fileName);
		if(!file.exists()) {
			this.sendErrorMessage(404, "file not found");
			return ;
		}
		try {
			InputStream in = new FileInputStream(file);
			byte content[] = new byte[(int)file.length()];
			try {
				in.read(content);
				out.println("HTTP/1.0 200 queryfile");
				out.println("content-length："+content.length);
				out.println();
				out.write(content);
				out.flush();
				in.close();
			} catch (IOException e) {
				
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
		
			e.printStackTrace();
		}
		
	}
}
