package com.webserver;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class WebServer {

	/**
	 * @param args
	 */

	public void serverStart(int port) {
		try {
			ServerSocket serverSocket = new ServerSocket(port);
			while (true) {
				/* accept()方法：Listens for a connection to be made to this socket and accepts it. 
				 * The method blocks until a connection is made. 
				 */
				Socket socket = serverSocket.accept();
				new Processor(socket).start();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int port = 8080;//定义服务器端口号，该端口号不可被其他进程占用
		if (args.length == 1) {
			port = Integer.parseInt(args[0]);
		}
		new WebServer().serverStart(port);//调用服务器启动方法

	}

}
