/** Automatically generated file. DO NOT MODIFY */
package com.devdiv.test.ui_test_gallery2;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}