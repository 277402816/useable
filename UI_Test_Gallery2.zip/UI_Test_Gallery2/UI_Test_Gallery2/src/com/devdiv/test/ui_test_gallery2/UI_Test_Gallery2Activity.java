package com.devdiv.test.ui_test_gallery2;

/*
 * 1��ע��ImageSwitcher��setFactory�ķ���
 *      myImageSwitcher.setFactory(new ViewFactory() {	
 *			@Override
 *			public View makeView() {
 *				// TODO Auto-generated method stub
 *			}
 *		});
 *
 * 2��myImageSwitcher.setInAnimation(AnimationUtils.loadAnimation(this, android.R.anim.fade_in))
 *    myImageSwitcher.setOutAnimation(AnimationUtils.loadAnimation(this, android.R.anim.fade_out))
 *    
 * 3��ע��myGallery.setOnItemSelectedListener()��ʹ�÷���
 * 
 * 4������myImageView.setBackgroundColor(0xff0000)���ȥ������ʾЧ����������ԭ����
 */

import android.app.Activity;
import android.content.Context;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.BaseAdapter;
import android.widget.Gallery;
import android.widget.Gallery.LayoutParams;
import android.widget.ImageSwitcher;
import android.widget.ImageView;
import android.widget.ViewSwitcher.ViewFactory;

public class UI_Test_Gallery2Activity extends Activity {
	
	private int[] imageId = {R.drawable.i1, R.drawable.i2, R.drawable.i3, R.drawable.i4,
            R.drawable.i1, R.drawable.i2, R.drawable.i3, R.drawable.i4,
            R.drawable.i1, R.drawable.i2, R.drawable.i3, R.drawable.i4,};
	
	private ImageSwitcher myImageSwitcher;;
	private Gallery myGallery;;
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        myImageSwitcher = (ImageSwitcher) findViewById(R.id.myImageSwitcher);
        myGallery = (Gallery) findViewById(R.id.myGallery);
        myGallery.setAdapter(new ImageAdapter(this));
        
        myImageSwitcher.setFactory(new ViewFactory() {
			
			@Override
			public View makeView() {
				// TODO Auto-generated method stub
				ImageView myImageView = new ImageView(UI_Test_Gallery2Activity.this);
				
				//ȥ����仰֮��Ч����ʾ��������Gallery�е�ͼƬ����ֻ�ɫ
				//��ʱ��û�ҵ�ԭ��
				myImageView.setBackgroundColor(android.R.color.white);
//				myImageView.setBackgroundColor(0xff0000);
				
				myImageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
				myImageView.setLayoutParams(new ImageSwitcher.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
				
				return myImageView;
			}
		});
        
        
        //����ImageSwitcher���л�����Ч��
        myImageSwitcher.setInAnimation(AnimationUtils.loadAnimation(this, android.R.anim.fade_in));
        myImageSwitcher.setOutAnimation(AnimationUtils.loadAnimation(this, android.R.anim.fade_out));
        
        myGallery.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> parent, View view,
					int position, long id) {
				// TODO Auto-generated method stub
				myImageSwitcher.setImageResource(imageId[position]);
				
			}

			@Override
			public void onNothingSelected(AdapterView<?> parent) {
				// TODO Auto-generated method stub
				
			}
		});
        
    }
    
    public class ImageAdapter extends BaseAdapter {
    	
    	Context myContext;
    	private int myGalleryItemBackground;
    	
    	
    	public ImageAdapter(Context context) {
    		myContext = context;
    		
    		TypedArray a = obtainStyledAttributes(R.styleable.Gallery);
    		myGalleryItemBackground = a.getResourceId(R.styleable.Gallery_android_galleryItemBackground, 0);
    		a.recycle();
    	}

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return imageId.length;
		}

		@Override
		public Object getItem(int position) {
			// TODO Auto-generated method stub
			return imageId[position];
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			// TODO Auto-generated method stub
			ImageView myImageView = new ImageView(myContext);
			//����ImageView�ڵ�ͼƬ��Դ
			myImageView.setImageResource(imageId[position]);
			//���ñ�����
			myImageView.setBackgroundResource(myGalleryItemBackground);
			//����ͼƬ������ģʽ
			myImageView.setScaleType(ImageView.ScaleType.FIT_XY);
			//����ImageView�Ĳ��֣�300*420
			myImageView.setLayoutParams(new Gallery.LayoutParams(75, 100));
			
			return myImageView;
		}

    }
}